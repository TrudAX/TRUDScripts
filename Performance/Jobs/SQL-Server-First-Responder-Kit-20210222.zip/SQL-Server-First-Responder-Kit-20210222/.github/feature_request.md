---
name: Feature request
about: Suggest an idea for this project

---

Fixes # .

Changes proposed in this pull request:
 - 

How to test this code:
 - 

Has been tested on (remove any that don't apply):
 - Case-sensitive SQL Server instance
 - SQL Server 2008
 - SQL Server 2008 R2
 - SQL Server 2012
 - SQL Server 2014
 - SQL Server 2016
 - SQL Server 2017
 - SQL Server 2019
 - Amazon RDS
 - Azure SQL DB
