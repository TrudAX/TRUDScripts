These old versions worked on SQL Server 2005.

They are no longer maintained or updated.

Don't use 'em on SQL Server 2008 or newer - these are only for folks who still
need to manage SQL Server 2005.